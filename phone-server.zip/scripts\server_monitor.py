#!/usr/bin/env python3
# =============================================================================
# server_monitor.py
# Monitora lo stato del server cloud e dei servizi in esecuzione su Termux
# Invia le metriche a InfluxDB
# Eseguire sul telefono server (Termux)
# =============================================================================

import subprocess
import requests
import time
import socket
import os
from datetime import datetime

# ===================== CONFIGURAZIONE =====================
INFLUXDB_URL = "http://localhost:8086"
INFLUXDB_DB = "server_status"
COLLECTION_INTERVAL = 30                    # Secondi

# Servizi da monitorare (nome processo e porta)
SERVICES_TO_MONITOR = [
    {"name": "influxdb", "process": "influxd", "port": 8086},
    {"name": "grafana", "process": "grafana-server", "port": 3000},
    # Aggiungi qui i tuoi servizi cloud:
    # {"name": "nextcloud", "process": "php-fpm", "port": 8080},
    # {"name": "syncthing", "process": "syncthing", "port": 8384},
    # {"name": "code-server", "process": "code-server", "port": 8443},
]

# Host da pingare per verificare la connettività
PING_TARGETS = [
    {"name": "gateway", "host": "192.168.1.1"},
    {"name": "pc_windows", "host": "192.168.1.2"},
    {"name": "huawei_display", "host": "192.168.1.11"},
    # {"name": "internet", "host": "8.8.8.8"},
]
# ==========================================================


def write_to_influxdb(measurement, tags, fields, timestamp=None):
    """Scrive un punto dati in InfluxDB"""
    tag_str = ",".join([f"{k}={v}" for k, v in tags.items()])
    field_str = ",".join([f"{k}={v}" for k, v in fields.items()])

    if tag_str:
        line = f"{measurement},{tag_str} {field_str}"
    else:
        line = f"{measurement} {field_str}"

    if timestamp:
        line += f" {timestamp}"

    try:
        url = f"{INFLUXDB_URL}/write"
        params = {"db": INFLUXDB_DB, "precision": "s"}
        response = requests.post(url, params=params, data=line, timeout=5)
        return response.status_code in [200, 204]
    except Exception as e:
        print(f"[ERRORE] InfluxDB write: {e}")
        return False


def check_process_running(process_name):
    """Controlla se un processo è in esecuzione"""
    try:
        result = subprocess.run(
            ["pgrep", "-f", process_name],
            capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def check_port_open(host, port, timeout=3):
    """Controlla se una porta è aperta"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False


def ping_host(host, timeout=3):
    """Pinga un host e restituisce il tempo di risposta in ms"""
    try:
        result = subprocess.run(
            ["ping", "-c", "1", "-W", str(timeout), host],
            capture_output=True, text=True, timeout=timeout + 2
        )
        if result.returncode == 0:
            # Estrai il tempo dal risultato
            output = result.stdout
            for line in output.split("\n"):
                if "time=" in line:
                    time_str = line.split("time=")[1].split(" ")[0]
                    return float(time_str)
            return 0.0
        return -1.0  # Host non raggiungibile
    except Exception:
        return -1.0


def get_termux_battery_info():
    """Ottiene informazioni sulla batteria del telefono server"""
    try:
        result = subprocess.run(
            ["termux-battery-status"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            import json
            battery = json.loads(result.stdout)
            return battery
    except Exception:
        pass
    return None


def get_disk_usage():
    """Ottiene l'utilizzo disco"""
    try:
        statvfs = os.statvfs(os.path.expanduser("~"))
        total = statvfs.f_frsize * statvfs.f_blocks
        free = statvfs.f_frsize * statvfs.f_bavail
        used = total - free
        percent = (used / total) * 100 if total > 0 else 0
        return {
            "total_mb": round(total / (1024 * 1024), 1),
            "used_mb": round(used / (1024 * 1024), 1),
            "free_mb": round(free / (1024 * 1024), 1),
            "percent": round(percent, 1)
        }
    except Exception:
        return None


def get_memory_usage():
    """Ottiene l'utilizzo memoria"""
    try:
        with open("/proc/meminfo", "r") as f:
            meminfo = {}
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = int(parts[1].strip().split()[0])  # in kB
                    meminfo[key] = value

            total = meminfo.get("MemTotal", 0)
            available = meminfo.get("MemAvailable", meminfo.get("MemFree", 0))
            used = total - available
            percent = (used / total) * 100 if total > 0 else 0

            return {
                "total_mb": round(total / 1024, 1),
                "used_mb": round(used / 1024, 1),
                "available_mb": round(available / 1024, 1),
                "percent": round(percent, 1)
            }
    except Exception:
        return None


def get_cpu_load():
    """Ottiene il carico CPU dal telefono server"""
    try:
        with open("/proc/loadavg", "r") as f:
            parts = f.read().strip().split()
            return {
                "load_1m": float(parts[0]),
                "load_5m": float(parts[1]),
                "load_15m": float(parts[2])
            }
    except Exception:
        return None


def collect_and_store():
    """Raccoglie tutte le metriche e le salva"""
    now = datetime.now().strftime('%H:%M:%S')

    # === 1. Stato servizi ===
    services_online = 0
    services_total = len(SERVICES_TO_MONITOR)

    for service in SERVICES_TO_MONITOR:
        process_running = check_process_running(service["process"])
        port_open = check_port_open("localhost", service["port"])
        is_online = process_running and port_open

        if is_online:
            services_online += 1

        tags = {"service": service["name"]}
        fields = {
            "online": "1i" if is_online else "0i",
            "process_running": "1i" if process_running else "0i",
            "port_open": "1i" if port_open else "0i"
        }

        write_to_influxdb("service_status", tags, fields)

    print(f"[{now}] Servizi: {services_online}/{services_total} online")

    # === 2. Ping targets ===
    for target in PING_TARGETS:
        ping_ms = ping_host(target["host"])
        is_reachable = ping_ms >= 0

        tags = {"target": target["name"], "host": target["host"]}
        fields = {
            "reachable": "1i" if is_reachable else "0i",
            "ping_ms": ping_ms if is_reachable else 0.0
        }

        write_to_influxdb("ping_status", tags, fields)

    # === 3. Metriche telefono server ===
    # Disco
    disk = get_disk_usage()
    if disk:
        write_to_influxdb("server_resources", {"resource": "disk"}, {
            "total_mb": disk["total_mb"],
            "used_mb": disk["used_mb"],
            "free_mb": disk["free_mb"],
            "percent": disk["percent"]
        })

    # Memoria
    mem = get_memory_usage()
    if mem:
        write_to_influxdb("server_resources", {"resource": "memory"}, {
            "total_mb": mem["total_mb"],
            "used_mb": mem["used_mb"],
            "available_mb": mem["available_mb"],
            "percent": mem["percent"]
        })

    # CPU Load
    cpu = get_cpu_load()
    if cpu:
        write_to_influxdb("server_resources", {"resource": "cpu"}, {
            "load_1m": cpu["load_1m"],
            "load_5m": cpu["load_5m"],
            "load_15m": cpu["load_15m"]
        })

    # Batteria
    battery = get_termux_battery_info()
    if battery:
        tags = {"resource": "battery"}
        fields = {
            "percentage": float(battery.get("percentage", 0)),
            "temperature": float(battery.get("temperature", 0))
        }
        status = battery.get("status", "UNKNOWN")
        fields["charging"] = "1i" if status == "CHARGING" else "0i"
        write_to_influxdb("server_resources", tags, fields)

    # === 4. Stato globale server ===
    server_online = services_online > 0
    write_to_influxdb("server_global", {}, {
        "online": "1i" if server_online else "0i",
        "services_total": f"{services_total}i",
        "services_online": f"{services_online}i"
    })


def main():
    print(f"Server Monitor avviato")
    print(f"  Servizi monitorati: {len(SERVICES_TO_MONITOR)}")
    print(f"  Ping targets: {len(PING_TARGETS)}")
    print(f"  Intervallo: {COLLECTION_INTERVAL}s")
    print(f"  InfluxDB: {INFLUXDB_URL}/{INFLUXDB_DB}")
    print("")

    while True:
        collect_and_store()
        time.sleep(COLLECTION_INTERVAL)


if __name__ == "__main__":
    main()
